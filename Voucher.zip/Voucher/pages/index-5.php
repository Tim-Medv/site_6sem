<html>
<head>
<title>Контрольная работа</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../css/style.css" rel="stylesheet" type="text/css">
</head>

<body topmargin="0" bottommargin="0" rightmargin="0"  leftmargin="0"   background="../images/back_main.gif">
<table cellpadding="0" cellspacing="0" border="0"  align="center" width="583" height="614">
	<tr>
		<td valign="top" width="583" height="208" background="../images/row1.gif">
			<div style="margin-left:88px; margin-top:57px "><img src="../images/w1.gif"></div>
			<div style="margin-left:50px; margin-top:69px ">
				<a href="../index.php">Главная<img src="../images/m1.gif" border="0" ></a>
				<img src="../images/spacer.gif" width="20" height="10">
				<a href="index-1.php">Заказ<img src="../images/m2.gif" border="0" ></a>
				<img src="../images/spacer.gif" width="5" height="10">
				<a href="index-2.php">Прайс<img src="../images/m3.gif" border="0" ></a>
				<img src="../images/spacer.gif" width="5" height="10">
				<a href="index-3.php">О компании<img src="../images/m4.gif" border="0" ></a>
				<img src="../images/spacer.gif" width="5" height="10">
				<a href="index-4.php">Контакты<img src="../images/m5.gif" border="0" ></a>
				
			</div>
		</td>
	</tr>
	<tr>
		<td valign="top" width="583" height="338"  bgcolor="#FFFFFF">
			<table cellpadding="0" cellspacing="0" border="0">
				<tr>
					<td valign="top" height="338" width="42"></td>
					<td valign="top" height="338" width="492">
						<table cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td width="492" valign="top" height="338">
								<div><img src="../images/5_w1.gif" ></div>
								<div style="margin-left:0px; margin-top:1px; margin-right:10px ">
								<font class="title">Fusce euismod consequat ante faucibus orci luctus</font><br>
Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod.<br><br>

Praesent justo dolor, lobortis quis, lobortis dignissim, pulvinar ac, lorem.</font> <br>
Vestibulum sed ante. Donec sagittis euismod purus us leo vel metus. Nulla facilisi. Aenean nec eros. Vestibu lum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia.<br><br>

<font class="title">Suspen isse sollicitudin velit sed leo.</font> <br>
Ut pharetra augue nec augue. Nam elit magna, hendrerit sit amet, tincidunt ac, viverra sed, nulla. Donec porta diam eu massa. Quisque diam lorem, interdum vitae, dapibus ac, scelerisque vitae, pede. Donec eget tellus non erat lacinia fermentum. Donec in velit vel ipsum auctor pulvinar. Proin ullamcorper urna et felis.
sam voluptatem dolores voluptatem sequi nesciunt.<br><br>

<font class="title">Fusce euismod consequat ante faucibus orci luctus</font><br>
Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod. Vestibulum sed ante. Donec sagittis euismod purus us leo vel metus. Nulla facilisi. Aenean nec eros. Vestibu lum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia.<br><br>

<font class="title">Suspen isse sollicitudin velit sed leo.</font> <br>
Ut pharetra augue nec augue. Nam elit magna, hendrerit sit amet, tincidunt ac, viverra sed, nulla. Donec porta diam eu massa. E-mail: <a href="#" class="title" style="text-decoration:underline ">mail@companyname.com</a><br>
								</div>
								</td>
							</tr>
							
						</table>
					</td>
					<td valign="top" height="338" width="49"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td valign="top" width="583" height="68" background="../images/row3.gif">
			<div style="margin-left:51px; margin-top:31px ">
				<a href="#"><img src="../images/p1.gif" border="0"></a>
				<img src="../images/spacer.gif" width="26" height="9">
				<a href="#"><img src="../images/p2.gif" border="0"></a>
				<img src="../images/spacer.gif" width="30" height="9">
				<a href="#"><img src="../images/p3.gif" border="0"></a>
				<img src="../images/spacer.gif" width="149" height="9">
				<a href="index-5.php"><img src="../images/copyright.gif" border="0"></a>
			</div>
		</td>
	</tr>
</table>
</body>
</html>
